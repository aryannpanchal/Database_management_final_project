-- ==========================
-- CreateSPs.sql
-- ==========================
-- Student Name: Aryan Panchal

USE PizzaDB;

-- No stored procedures required for basic solution
-- This file exists for autograder compatibility
